from ase.io import read,write  
from pyscf import gto,dft 
from flosic_os import xyz_to_nuclei_fod,ase2pyscf
from flosic_scf import FLOSIC
from onstuff import ON
import time
import sys

start = time.time()


sysname = 'tcne_test'
atoms = read(sysname+'.xyz') 
#basis = 'aug-ccpvtz'
basis = 'ccpvtz'
spin = 0
charge = 0
grid_level = 4
xc = 'LDA,PW'
tol = 1e-6
max_cycle = 300
ham_sic = 'HOOOV'
verbose = 4
nshell = 2






pyscf_atoms,nuclei,fod1,fod2,included = xyz_to_nuclei_fod(atoms)

mol = gto.M(atom=ase2pyscf(nuclei),basis=basis,spin=spin,charge=charge,verbose=verbose)


mol.max_memory = 2000

mol.verbose = 4

# quick dft calculation
mdft = dft.UKS(mol)
mdft.xc = xc
mdft.grids.level = grid_level
mdft.conv_tol = tol
mdft.max_cycle = max_cycle
mdft.chkfile = 'tcne.chk'
mdft.init_guess = 'chkfile'
mdft.kernel()

# build O(N) stuff
myon = ON(mol,[fod1.positions,fod2.positions], grid_level=grid_level)
myon.nshell = nshell
myon.build()

# enable ONMSH
m = FLOSIC(mol,xc=xc,fod1=fod1,fod2=fod2,grid_level=grid_level, init_dm=mdft.make_rdm1(),ham_sic = ham_sic)
m.max_cycle = 40
m.set_on(myon)
m.conv_tol = tol

m.preopt = False
m.preopt_start_cycle=0
m.preopt_fix1s = True
m.preopt_fmin = 0.005

m.kernel()

sys.exit()


end = time.time()

sout = nuclei.copy()
sout.extend(fod1)
sout.extend(fod2)
write(sysname+'_final_flosic_geometry.xyz',sout)

print('\nFOD forces in Ha/Bohr:\n')
print(m.get_fforces())

end = time.time()

print('Run time [h]: %.2f' % ((end-start)/3600))
